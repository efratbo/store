<!-- פרויקט בריאקט- קריאות שרת

התחברות-לאחר שהמשתמש ממלא את פרטיו בעמוד לוגין (התחברות)
http://localhost:4000/user/login    method: 'post' 

יצירת משתמש חדש
http://localhost:4000/user    method: 'post' 

יצירת מוצר חדש
http://localhost:4000/product    method: 'post'

קבלת כל המוצרים
http://localhost:4000/product    method: 'get' 

יצירת הזמנה חדשה
http://localhost:4000/order    method: 'post' 

קבלת כל ההזמנות
http://localhost:4000/order    method: 'get' 

קבלת הזמנה לפי מזהה id 
http://localhost:4000/order/id    method: 'get' 
 -->





