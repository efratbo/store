import { Image } from "semantic-ui-react"
const ButtonExampleButton = () => {
    return (<>
        <p>try 1</p>
       
    </>)
}

export default ButtonExampleButton