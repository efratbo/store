import UserNav from '../navs/userNav'
import GuestNav from '../navs/guestNav'
import ManagerNav from '../navs/managerNav'

export default function ProjectIndex(){
    return(<div className="divPink">
        <GuestNav></GuestNav>
    </div>)
}