export const idle="idle";
export const fulfilled="fulfilled"
export const rejected="relected"
export const pending = "peding"
export const manager = "manager"