import './App.css';
import GeneralNav from './Components/final_project/navs/generalNav'
function App() {
  return (
   <GeneralNav></GeneralNav>
  );
}

export default App;
